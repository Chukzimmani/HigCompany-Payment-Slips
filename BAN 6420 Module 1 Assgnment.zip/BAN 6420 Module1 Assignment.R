set.seed(123)
 #Function t generate random names
generate_name <- function() {
  paste0(sample(LETTERS, 5, replace = TRUE), collapse="")
}

# Function to generate random gender
generate_gender <- function() {
  sample(c('Male', 'Female'), 1)
}

# Function to generate random salary
generate_salary <- function() {
  sample(5000:35000, 1)
}

# Generate a list of 500 workers
workers <- data.frame (
  name = replicate(500, generate_name()),
  gender = replicate(500, generate_gender()),
  salary = replicate(500, generate_salary()),
  stringsAsFactors=FALSE
)

# Function to determine employee level
determine_employee_level <- function(worker) {
  tryCatch({
    salary <- worker$salary
    gender <- worker$gender
    level <- "None"
    
    if (salary > 10000 & salary < 20000) {
      level <- "A1"
    }
    if (salary > 7500 & salary < 30000 & gender == "Female") {
      level <- "A5-F"
    }
    
    return(level)
  }, error=function(e) {
    print(paste("Error:", e))
    return("Error")
  })
}


# Generate payment slips
for (i in 1: nrow(workers)) {
  workers$employee_level[i] <- determine_employee_level(workers [i, ])
  cat(sprintf("Payment slip for %s:/n", workers$name[i]))
  cat(sprintf(" Gender: %s/n", workers$gender[i]))
  cat(sprintf(" Salary: %d/n", workers$salary[i]))
  cat(sprintf(" Employee Level: %s/n", workers$employee_level[i]))
  cat("/n")
}

# Save the workers list for further use if needed
write.csv(workers, 'workers.csv', row.names = FALSE)